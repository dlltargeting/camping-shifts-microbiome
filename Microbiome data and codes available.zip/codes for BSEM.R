
###############################################BSEM
library(brms)
# library(piecewiseSEM)
# library(lavaan)
# library(blavaan) # Fitting structural equation models
library(rstan)
options(mc.cores = parallel::detectCores())
rstan_options(auto_write = TRUE)
library(rstantools)
library("future") #set proceesor work mode
plan(multiprocess) #set proceesor work mode

#load data
load("E:/17th/niche_width.degree.re.RData")

names(ds)
head(ds)
ds$Niche_width<-log(ds$Niche_width)
ds$degree<-log(ds$degree)


#The brms
#The brms model formulae
group_mod <- bf(Niche_width ~ group3)
niche_mod <- bf(degree ~ Niche_width)

#wrap it together in one model
k_fit_brms <- brm(group_mod +
                    niche_mod + 
                    set_rescor(FALSE), 
                  data=ds,
                  cores=4, chains = 2)
summary(k_fit_brms)

#check it
plot(k_fit_brms)


#plot to check convergence
plot(k_fit_brms)



WAIC(k_fit_brms)



