#library packages
library(WGCNA)     
library(reshape2)
library(stringr)
library(igraph)
options(stringsAsFactors = FALSE)
enableWGCNAThreads()

#input data
subgroup<-read.delim(file='16s.otu.txt',row.names = 1,  sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
subgroup<-sqrt(subgroup)[,c(4:6)]
group<-"nocamping"

otu<-as.data.frame(t(subgroup))




#
occor =corAndPvalue(otu,method="pearson",use="p")             
occor.r = occor$cor
occor.p = occor$p 
occor.p<-p.adjust(occor.p, method = "BH", n = length(occor.p))
occor.r[is.na(occor.r) ] = 0
occor.p[is.na(occor.p) ] = 1
occor.r[occor.p>=0.001| abs(occor.r)<=0.8 ] = 0

igraph = graph_from_adjacency_matrix(occor.r,mode="undirected",weighted=TRUE,diag=FALSE)
bad.vs = V(igraph)[degree(igraph) == 0]
igraph = delete.vertices(igraph, bad.vs)
igraph<-simplify(igraph)
igraph.weight = E(igraph)$weight
V(igraph)$label <-V(igraph)$name
V(igraph)$degree <- degree(igraph)

E(igraph)$weight = NA
sum(igraph.weight>0)
sum(igraph.weight<0)

E.color = igraph.weight
E.color = ifelse(E.color>0, "red",ifelse(E.color<0, "blue","grey"))
E(igraph)$color = as.character(E.color)

edge <- data.frame(as_edgelist(igraph))

#output edgelist
edge_list <- data.frame(
  source = edge[[1]],
  target = edge[[2]],
   colors = E.color)
write.csv(edge_list,paste0(group,'.edge_list.csv'), row.names = FALSE, quote = FALSE)

# output node list
node_list <- data.frame(
  Id      = V(igraph)$name,
  degree  = degree(igraph)
)
write.csv(node_list, paste0(group,'.node_list.csv'), row.names = FALSE, quote = FALSE)
