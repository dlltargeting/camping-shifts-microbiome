###########################################################
# https://cran.r-project.org/web/packages/spaa/spaa.pdf
# https://github.com/helixcn/spaa
###########################################################

library(spaa)

##########16S
otus <- read.delim(file=choose.files(),row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)#, check.names = TRUEFALSE
names(otus)
otux<-as.data.frame(t(otus))
rownames(otux)


otu<-otux[1:3,]
nodes_list <- read.csv(choose.files())
otu<-otu[,nodes_list$Id]

niche_width <- niche.width(otu, method = 'levins')


Camping<-as.data.frame(matrix(unlist(niche_width),ncol=1, byrow=F),stringsAsFactors=FALSE)

Camping[which(Camping==Inf),]<-NA
B.Camping=apply(Camping,2,function(x){
  x[is.na(x)]=max(x,na.rm = T)
  return(x)
})
mean(B.Camping)



##########ITS
otus <- read.delim(file=choose.files(),row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)#, check.names = TRUEFALSE
names(otus)
otux<-as.data.frame(t(otus))
rownames(otux)

otu<-otux[1:3,]
niche_width <- niche.width(otu, method = 'levins')


Camping<-as.data.frame(matrix(unlist(niche_width),ncol=1, byrow=F),stringsAsFactors=FALSE)

Camping[which(Camping==Inf),]<-NA
F.Camping=apply(Camping,2,function(x){
  x[is.na(x)]=max(x,na.rm = T)
  return(x)
})
mean(F.Camping)

ds<-as.data.frame(rbind(B.Camping,B.No_Camping,F.Camping,F.No_Camping))

names(ds)<-"Niche_width"
ds$group<-rep(c(rep("B.Camping",dim(B.Camping)[1]),rep("B.No_Camping",dim(B.No_Camping)[1]),rep("F.Camping",dim(F.Camping)[1]),rep("F.No_Camping",dim(F.No_Camping)[1])))

library(ggplot2)

p <- ggplot(ds, aes(x = group, y = Niche_width, color = group)) +
  geom_jitter(size = 1.5, width = 0.2, show.legend = FALSE) +  
   scale_color_manual(values = c("#1F77B4", "#FF7F0E","#41A541","#D62728")) + 
  theme(panel.grid = element_blank(), panel.background = element_blank(), 
        axis.line = element_line(color = 'black')) + 
  stat_summary(fun.y = mean, fun.ymin = mean, fun.ymax = mean, 
               geom = 'crossbar', width = 0.3, size = 0.3, color = 'black') + 
  stat_summary(fun.data = function(x) mean_cl_boot(x, conf.int=.95), 
               geom = 'errorbar', width = 0.25, size = 0.2, color = 'black') +
  stat_compare_means(comparisons=my_comparisons) +
  theme_bw()+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())
ggsave(p, filename = 'Niche_width.pdf', width = 4, height = 4)




library(ggplot2)

p <- ggplot(ds, aes(x = group, y = Niche_overlap, color = group)) +
  geom_jitter(size = 1.5, width = 0.2, show.legend = FALSE) + 
  scale_color_manual(values = c("#1F77B4", "#FF7F0E","#41A541","#D62728")) + 
  theme(panel.grid = element_blank(), panel.background = element_blank(), 
        axis.line = element_line(color = 'black')) +  
  stat_summary(fun.y = mean, fun.ymin = mean, fun.ymax = mean, 
               geom = 'crossbar', width = 0.3, size = 0.3, color = 'black') + 
  stat_summary(fun.data = function(x) mean_cl_boot(x, conf.int=.95), 
               geom = 'errorbar', width = 0.25, size = 0.2, color = 'black') + 
  stat_compare_means(comparisons=my_comparisons) +
  theme_bw()+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())
p
ggsave(p, filename = 'Niche_overlap.pdf', width = 4, height = 4)



p <- ggplot(ds, aes(x = group, y = Niche_overlap, color = group)) +
  geom_boxplot(width=0.3,position = position_dodge(0.8), show.legend = FALSE) + 
 
  scale_color_manual(values = c("#1F77B4", "#FF7F0E","#41A541","#D62728")) + 
  theme(panel.grid = element_blank(), panel.background = element_blank(), 
        axis.line = element_line(color = 'black')) + 

  stat_summary(fun.y = mean, fun.ymin = mean, fun.ymax = mean, 
               geom = 'crossbar', width = 0.3, size = 0.3, color = 'black') + 
  stat_summary(fun.data = function(x) mean_cl_boot(x, conf.int=.95), 
               geom = 'errorbar', width = 0.25, size = 0.2, color = 'black') + 
  stat_compare_means(comparisons=my_comparisons) +
  theme_bw()+theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())
p
ggsave(p, filename = 'Niche_overlap.pdf', width = 4, height = 4)



#######################generalist and specilist
###############################################
library(EcolUtils)

otus <- read.delim(file=choose.files(),row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)

otuid<-rownames(otus)

otus <- read.delim(file=choose.files(),row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
otus<-otus[which(rownames(otus)%in%otuid),]
names(otus)
otux<-as.data.frame(t(otus))
rownames(otux)

set.seed(123)
spec_gen <- spec.gen(otux, niche.width.method = 'levins', perm.method = 'quasiswap', n = 1000, probs = c(0.025, 0.975))
tail(spec_gen)

write.table(spec_gen, 'spec_gen_F.txt', sep = '\t', col.names = NA, quote = FALSE)

names(spec_gen)
otus<-otus/colSums(otus)
otus$sign<-spec_gen$sign
x<-aggregate(otus[1:6],by = list(x1 = otus$sign), FUN = sum) 
rownames(x)<-x$x1
y1<-as.data.frame(t(x[-1]))
y1$group<-rep(c("Camping","No camping"),each=3)
z<-aggregate(y[1:3],by = list(x1 = y$group), FUN = mean) 

library(reshape2)

s<-melt(z,id="x1")
names(s)[1]<-"group"
f<-s[-c(3,4),]
bf<-rbind(b,f)
bf$kingdom<-rep(c("Bacteria","Fungi"),each=4)


library(ggplot2)
ggplot(bf,aes(x=group,y=value*100,fill=variable))+
  geom_bar(stat="identity",position = "stack")+
  facet_wrap(~kingdom,scale="free")+
  theme_bw()

library(ggpubr)
compare_means(GENERALIST~group, data=xx,  method = "anova")
compare_means(GENERALIST~group, data=xx,  method = "t.test")
compare_means(SPECIALIST~group, data=xx,  method = "anova")
compare_means(SPECIALIST~group, data=xx,  method = "t.test")



bf<-rbind(y,y1)
bf$kingdom<-rep(c("Bacteria","Fungi"),each=6)


library(ggpubr)
compare_means(GENERALIST~kingdom, data=bf[bf$group=="Camping",],  method = "anova")
compare_means(GENERALIST~kingdom, data=bf[bf$group=="Camping",],  method = "t.test")



# niche change degree
###############################################################################
###############################################################################
#########################################################################

library(spaa)

B.Stay.degree.re<- read.delim(file="camping.b.niche_width.degree.re.subOTU.txt",row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
names(B.Stay.degree.re)[2:5]<-c("Niche_width",paste0("t",1:3))



B.No_stay.degree.re<- read.delim(file="No_camping.b.niche_width.degree.re.subOTU.txt",row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
names(B.No_stay.degree.re)[2:5]<-c("Niche_width",paste0("t",1:3))

##########ITS

F.Stay.degree.re<- read.delim(file="camping.f.niche_width.degree.re.subOTU.txt",row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
names(F.Stay.degree.re)[2:5]<-c("Niche_width",paste0("t",1:3))


F.No_stay.degree.re<- read.delim(file="No_camping.f.niche_width.degree.re.subOTU.txt",row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
names(F.No_stay.degree.re)[2:5]<-c("Niche_width",paste0("t",1:3))






##############

ds<-as.data.frame(rbind(B.Stay.degree.re,B.No_stay.degree.re,F.Stay.degree.re,F.No_stay.degree.re))


ds$group<-rep(c(rep("B.Stay.degree.re",dim(B.Stay.degree.re)[1]),rep("B.No_stay.degree.re",dim(B.No_stay.degree.re)[1]),rep("F.Stay.degree.re",dim(F.Stay.degree.re)[1]),rep("F.No_stay.degree.re",dim(F.No_stay.degree.re)[1])))
ds$group1<-rep(c(rep("Bacteria",c(dim(B.Stay.degree.re)[1]+dim(B.No_stay.degree.re)[1])),rep("Fungi",c(dim(F.Stay.degree.re)[1]+dim(F.No_stay.degree.re)[1]))))
ds$group2<-rep(c(rep("Camping",dim(B.Stay.degree.re)[1]),rep("No_camping",dim(B.No_stay.degree.re)[1]),rep("Camping",dim(F.Stay.degree.re)[1]),rep("No_camping",dim(F.No_stay.degree.re)[1])))
ds$group3<-rep(c(rep("1",dim(B.Stay.degree.re)[1]),rep("0",dim(B.No_stay.degree.re)[1]),rep("1",dim(F.Stay.degree.re)[1]),rep("0",dim(F.No_stay.degree.re)[1])))




library(ggplot2)
library(ggpubr)



my_comparisons <- list(c("B.Stay","B.No_stay"), c("F.Stay","F.No_stay"), 
                       c("B.Stay","F.Stay"),
                       
                       c("B.No_stay","F.No_stay"))

ds$group<-factor(ds$group,level=c("B.Stay","B.No_stay","F.Stay","F.No_stay"),ordered = TRUE)

ds<-na.omit(ds)


library(ggplot2)
library(ggpubr)

p<-ggplot(ds, aes(log(Niche_width),log(degree))) +
  geom_point(aes(),size=1,alpha=0.5)+
  geom_smooth(method = lm, se = TRUE)# +

ggsave(p, filename = 'Niche_width_.pdf', width = 4, height = 4)

##############################
# 
D<-function(Id=Id,v1,v2,data){
  n<-length(data$Id)
  id=NULL
  id_v1_delt=NULL
  id_v2_delt=NULL
  pairs<-combn(1:n,2)
  set.seed(999)
  cn<-sample(1:choose(n,2),5e+4,replace = FALSE)
  #
  for (i in c(cn)) {
  id_i<-paste0(data$Id[pairs[,i]],collapse = "_")
  id_v1_delt_i<-data[c(pairs[,i][1]),v1]-data[c(pairs[,i][2]),v1]
  id_v2_delt_i<-data[c(pairs[,i][1]),v2]-data[c(pairs[,i][2]),v2]

  id<-c(id,id_i)
  id_v1_delt<-c(id_v1_delt,id_v1_delt_i)
  id_v2_delt<-c(id_v2_delt,id_v2_delt_i)
  print(i)
  }
  dat <- data.frame(paired_id = id,v1_delt=id_v1_delt,v2_delt=id_v2_delt)

}


names(ds)
head(ds)
p<-ggplot(ds, aes(log(Niche_width),log(degree), color = degreegroup)) +
  geom_point(aes(color = degreegroup ),size=1,alpha=0.5)+
  geom_smooth(method = lm, se = TRUE)+
  facet_grid(group2~group1,  scale = 'free_y')
  
  
  facet_wrap(~group1, ncol = 2, scale = 'free_y')

p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="high_degree"&ds$group1=="Bacteria"&ds$group2=="Camping",])
summary(p.lm)
p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="low_degree"&ds$group1=="Bacteria"&ds$group2=="Camping",])
summary(p.lm)
p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="high_degree"&ds$group1=="Bacteria"&ds$group2=="No_camping",])
summary(p.lm)
p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="low_degree"&ds$group1=="Bacteria"&ds$group2=="No_camping",])
summary(p.lm)

p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="high_degree"&ds$group1=="Fungi"&ds$group2=="Camping",])
summary(p.lm)
p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="low_degree"&ds$group1=="Fungi"&ds$group2=="Camping",])
summary(p.lm)
p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="high_degree"&ds$group1=="Fungi"&ds$group2=="No_camping",])
summary(p.lm)
p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="low_degree"&ds$group1=="Fungi"&ds$group2=="No_camping",])
summary(p.lm)

head(ds)
p<-ggplot(ds, aes(log(Niche_width),log(degree), color = degreegroup)) +
  geom_point(aes(color = degreegroup ),size=1,alpha=0.5)+
  geom_smooth(method = lm, se = TRUE)




p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="high_degree",])
summary(p.lm)
p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="low_degree",])
summary(p.lm)


###
p<-ggplot(ds, aes(log(Niche_width),log(degree), color = degreegroup)) +
  geom_point(aes(color = degreegroup ),size=1,alpha=0.5)+
  geom_smooth(method = lm, se = TRUE)+
  facet_wrap(~group2, ncol = 2, scale = 'free_y')

p<-ggplot(ds, aes(log(Niche_width),log(degree), color = group2)) +
  geom_point(aes( color = group2),size=1,alpha=0.5)+
  geom_smooth(method = lm, se = TRUE)

p.lm1<-lm(log(degree)~log(Niche_width),data=ds[ds$group2=="Camping",])
summary(p.lm1)
p.lm2<-lm(log(degree)~log(Niche_width),data=ds[ds$group2=="No_camping",])
summary(p.lm2)

p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="high_degree"&ds$group2=="Camping",])
summary(p.lm)


p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="low_degree"&ds$group2=="Camping",])
summary(p.lm)

p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="high_degree"&ds$group2=="No_camping",])
summary(p.lm)


p.lm<-lm(log(degree)~log(Niche_width),data=ds[ds$degreegroup=="low_degree"&ds$group2=="No_camping",])
summary(p.lm)



